# Encoding: utf-8
# Cloud Foundry Java Buildpack
# Copyright 2015 the original author or authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

require 'java_buildpack/container'
require 'java_buildpack/container/tomcat'
require 'maven/ruby/maven'
require 'json'

module JavaBuildpack
  module Container

    # Encapsulates the detect, compile, and release functionality for Maven Archive applications.
    class MavenArchive < JavaBuildpack::Container::Tomcat

      alias :super_compile :compile

      def compile
        super_compile
        fetch_dependencies
      end

      def fetch_dependencies
        mvn = Maven::Ruby::Maven.new

        depsFile = File.read(dependencies_file)
        deps = JSON.parse(depsFile)
        deps['dependencies'].each { |dep|
          group = dep['groupId']
          artifact = dep['artifactId']
          version = dep['version']
          sha = dep['sha1']

          groupDirs = group.gsub('.', '/')
          artifactPath = "#{Dir.home}/.m2/repository/#{groupDirs}/#{artifact}/#{version}/#{artifact}-#{version}.jar"
          if !File.exist?(artifactPath)
            # fetch the dependency from the internet
            mvn.exec('dependency:get', "-Dartifact=#{group}:#{artifact}:#{version}")
          end
          
          # validate the sha1 hash
          actualsha = Digest::SHA1.file(artifactPath).hexdigest
          if actualsha != sha
            raise "SHA-1 mismatch for #{group}:#{artifact}:#{version}! Expected '#{sha}'; got '#{actualsha}'"
          end
          
          # make a symlink from the right spot in the lib dir to the target
          # TODO support for custom repository location env variable; classifiers
          FileUtils.ln_s(artifactPath, lib_dir)
        } 
      end

      protected

      # (see JavaBuildpack::Component::ModularComponent#supports?)
      def supports?
        web_inf? && maven_archive? && !JavaBuildpack::Util::JavaMainUtils.main_class(@application)
      end

      def maven_archive?
        dependencies_file.exist?
      end

      private

      def dependencies_file
        lib_dir + 'maven-dependencies.json'
      end

      def web_inf?
        (@application.root + 'WEB-INF').exist?
      end

      def lib_dir
        @application.root + 'WEB-INF/lib/'
      end

    end

  end
end
